0.6.3 UPDATE — current behavior
Settings supports26.30(default),26.40 and26.50 matching engines. Saved sign-in is encrypted using Android Keystore-wrapped AES-GCM or Windows user DPAPI, restored on app reopen/version switch, refreshed when required, and removed by Sign out. Proxy connections do not restart automatically. Microsoft can require reauthentication. The browser never receives stored tokens. An explicit Minecraft UserBusy form cancellation now retries the home menu up to3 times; intentionally closing it does not reopen it. Real Quest/Windows testing is still required. This is not protocol translation: the destination must support the selected client protocol. Via-style26.30→26.40 translation is not implemented.

LUNARVOID PROXY 0.6.3-experimental — BEDROCK COMPANION

OPEN THE WEBSITE INTERFACE
Extract this ZIP and open index.html for downloads. Open dashboard/index.html
for the interface,
saved preferences and client-menu preview. A browser tab alone cannot host a
Bedrock UDP relay. Nothing is deployed to LunarVoidProxy.com.

CONNECT FROM ANDROID
Use the separate LUNARVOID APK (Android 8 or newer). Add the destination
Bedrock address and port, select it, and press Start Proxy. On the same
Android device, join the displayed local address/port from Minecraft.
For another device, enable "Allow devices on the same Wi-Fi" before starting.
Join the shown Wi-Fi address/port or look in Minecraft Friends / LAN Games.
Discovery depends on device support, server responses and the router allowing
traffic between Wi-Fi devices. LAN mode continues after closing the app window. Force-stop, shutdown and
battery restrictions can stop it. Press Stop Proxy to stop explicitly.

RUN THE WEBSITE WITH A RELAY ON YOUR COMPUTER
Install Python 3.10 or newer, then open a terminal in the extracted folder.
Run: python3 relay/server.py
On Windows, the command may be: py -3 relay/server.py
Open http://127.0.0.1:3000 in your browser. Add/select a destination and start
the proxy, then join the displayed address from Minecraft on that computer.
The default service is local to that computer. This is not public hosting.

WHAT THIS BUILD CAN DO
- Forward IPv4 Bedrock UDP traffic; Android also has optional LAN discovery.
- Manage saved servers and local nickname preference.
- Show the blue client menu, search/category module catalog and color previews.
- Save player-outline color, ore colors and AutoMine target on this device.

WHAT IS STILL MISSING
This is a preview companion, not an installed modification inside Minecraft.
All gameplay modules are unavailable. Edit HUD is reserved for later work.
World replay recording, playback, export and app/website replay sync are absent.
The replay editor is a UI preview; it does not edit Minecraft world recordings.
Nickname preferences cannot change your server-visible identity on arbitrary
servers. Server support and permission are required.
Bedrock26.30/26.50+ and future updates are targets, not verified compatibility.
Your Minecraft version must be accepted by the destination server.
Physical Android/Quest/console discovery and full Minecraft login/gameplay
have not been tested. The APK is a debug-signed preview for testing.

LOCAL STORAGE
Preferences are separate for each browser and the APK. There is no automatic
account or cloud sync. No Microsoft account-linking payment is required by
this companion. Minecraft and servers may have their own account requirements.

NEW IN THIS BUILD
All19 ore choices in AutoMine settings; skin PNG/3D toggle; saved app
preferences; local .mcstructure/.litematic build upload and outline preview.
Build outlines are only shown in the companion preview, not in Minecraft.
The original transparent mode has no emote activation. See the0.6 experimental
game mode instructions below. Gameplay modules remain unavailable.

PUBLISH THE DOWNLOAD WEBSITE
Upload index.html, dashboard/ and downloads/ from this ZIP to a static HTTPS
host. Keep the folders together: the landing page links to the bundled files.
Do not upload relay/ or V15/ to a static host; they are for local Python use.
For a short .net address, register a domain you own (for example
LunarVoidProxy.net, if available), add it in your host's custom domain settings,
and set the DNS records exactly as the host specifies. Enable HTTPS there.
No domain is registered or deployed by this package. A public static dashboard
is a preview; run the apps for a local UDP relay. Do not expose the local relay
publicly without configuring its access key and network restrictions.

REBUILD FROM SOURCE
Build the dashboard and Android APK, then run tools/build_desktop.py and
python3 tools/package.py. The website build checks that both downloads contain
the current dashboard before publishing them in the package.

0.6 EXPERIMENTAL GAME ENGINE
The APK (ARM64 Android8+) and Windows app include an opt-in Bedrock26.30/26.50
engine. From Play: sign in for game mode with the same account as Minecraft,
select a compatible destination, then Start game proxy. Join the displayed
address and play an actual emote to open a standard Minecraft form menu.
Profile stores a local nickname preference; Settings changes menu cooldown;
Edit HUD explains that custom HUD/replay work is unavailable. This does not
activate gameplay modules. Microsoft linking has no fee charged by LUNARVOID.
Tokens stay in process memory. Reopen/sign in after Android process death.
Servers with resource packs, other Bedrock versions, subclients, transfers and
full real-device gameplay are not supported/verified by this experimental build.
The website alone cannot run this engine; use the APK/PC app. The menu uses
Minecraft's form style, not the custom blue preview overlay.
Rebuild native components with python3 tools/build_engine.py before Android or
PC packaging. Requires Go1.26.1, Android NDK27.2.12479018 and the existing tools.

VERSION SELECTION
Settings > Bedrock version chooses the matching engine26.30(default) or26.50.
Stop game mode before changing it. A change signs you out; sign in again.
This does not update Minecraft or let26.30 join a26.50-only destination.
The chosen engine must match both the game and server protocol.


0.6.2 connection update: Sign in from Settings, then select a server in Play and press Start Proxy. The primary control now uses the native emote engine; the separate game-mode start/stop panel is removed. Starting stops any legacy forwarding-only relay first. Join the displayed endpoint, select and play an actual emote, or use /.menu. The connection description displays the received emote count. /.help and module aliases (for example /.xray, /.fly, /.automine) are local commands; module aliases report Unavailable because gameplay modules are unfinished. Other server commands pass through. Real-device verification remains pending.
