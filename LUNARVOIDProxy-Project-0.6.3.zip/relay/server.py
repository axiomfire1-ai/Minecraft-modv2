#!/usr/bin/env python3
"""LUNARVOID web controller and bounded, transparent IPv4 UDP relay."""
import argparse
import hmac
import ipaddress
import json
import os
from pathlib import Path
import re
import secrets
import selectors
import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[1]


def resolve_target(host, port, allow_lan=False):
    if not isinstance(host, str) or not re.fullmatch(r"[A-Za-z0-9.-]{1,253}", host):
        raise ValueError("Enter an IPv4 address or server hostname without a URL or port.")
    if type(port) is not int or not 1 <= port <= 65535:
        raise ValueError("Port must be a whole number from 1 to 65535.")
    try:
        addresses = socket.getaddrinfo(host, port, socket.AF_INET, socket.SOCK_DGRAM)
    except socket.gaierror as exc:
        raise ValueError("The server address could not be resolved.") from exc
    for item in addresses:
        address = item[4]
        ip = ipaddress.ip_address(address[0])
        if ip.is_multicast or ip.is_unspecified or address[0] == "255.255.255.255":
            continue
        if not allow_lan and not ip.is_global:
            continue
        return address
    raise ValueError("This relay host does not allow that destination address.")


class Relay:
    """One listening port, separate connected upstream socket per client endpoint."""
    def __init__(self, target, bind="127.0.0.1", ports=(0, 0), idle=600, peer_idle=120):
        self.target = target
        self.idle, self.peer_idle = idle, peer_idle
        self.created = self.last_packet = time.monotonic()
        self.sent = self.received = 0
        self.error = None
        self.stop_event = threading.Event()
        self.listener = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.listener.setblocking(False)
        try:
            for port in range(ports[0], ports[1] + 1):
                try:
                    self.listener.bind((bind, port))
                    break
                except OSError:
                    if port == ports[1]:
                        raise ValueError("No relay ports are available. Try again later.")
            self.port = self.listener.getsockname()[1]
            if target[1] == self.port and (ipaddress.ip_address(target[0]).is_loopback or target[0] == bind):
                raise ValueError("The destination cannot be this relay's own listening address.")
        except Exception:
            self.listener.close()
            raise
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def _run(self):
        peers = {}
        selector = selectors.DefaultSelector()
        try:
            selector.register(self.listener, selectors.EVENT_READ, None)
            while not self.stop_event.is_set():
                now = time.monotonic()
                if now - self.last_packet > self.idle or now - self.created > 8 * 3600:
                    break
                for key, _ in selector.select(.2):
                    if key.data is None:
                        data, client = self.listener.recvfrom(65535)
                        if not data:
                            continue
                        if client not in peers:
                            if len(peers) >= 8:
                                continue
                            upstream = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                            try:
                                upstream.connect(self.target)
                                upstream.setblocking(False)
                                selector.register(upstream, selectors.EVENT_READ, client)
                            except Exception:
                                upstream.close()
                                raise
                            peers[client] = [upstream, now]
                        upstream, _ = peers[client]
                        try:
                            upstream.send(data)
                            self.sent += 1
                        except (BlockingIOError, ConnectionRefusedError):
                            pass
                        peers[client][1] = self.last_packet = now
                    else:
                        client = key.data
                        try:
                            data = key.fileobj.recv(65535)
                            self.listener.sendto(data, client)
                            self.received += 1
                            peers[client][1] = self.last_packet = now
                        except (BlockingIOError, ConnectionRefusedError):
                            pass
                for client, (upstream, last) in list(peers.items()):
                    if now - last > self.peer_idle:
                        selector.unregister(upstream)
                        upstream.close()
                        del peers[client]
        except OSError:
            if not self.stop_event.is_set():
                self.error = "The relay socket closed unexpectedly. Start it again."
        finally:
            self.stop_event.set()
            for upstream, _ in peers.values():
                upstream.close()
            selector.close()
            self.listener.close()

    def close(self):
        self.stop_event.set()
        self.thread.join(timeout=2)

    def snapshot(self, address):
        return {"state": "stopped" if self.stop_event.is_set() else "running",
                "address": address, "port": self.port,
                "packetsSent": self.sent, "packetsReceived": self.received,
                "error": self.error}


class Controller:
    def __init__(self, public_host="127.0.0.1", udp_bind="127.0.0.1", ports=(0, 0),
                 access_key="", allow_lan=False, max_sessions=16):
        self.public_host, self.udp_bind, self.ports = public_host, udp_bind, ports
        self.access_key, self.allow_lan = access_key, allow_lan
        self.max_sessions = max_sessions
        self.sessions = {}
        self.lock = threading.Lock()

    def start(self, host, port):
        target = resolve_target(host, port, self.allow_lan)
        if self.ports[0] and self.ports[0] <= target[1] <= self.ports[1]:
            try:
                own_addresses = {item[4][0] for item in socket.getaddrinfo(self.public_host, 0, socket.AF_INET, socket.SOCK_DGRAM)}
            except socket.gaierror:
                own_addresses = set()
            if target[0] in own_addresses:
                raise ValueError("Choose the destination server, not this relay host's listening ports.")
        with self.lock:
            self.sessions = {key: value for key, value in self.sessions.items()
                             if not value[1].stop_event.is_set()}
            if len(self.sessions) >= self.max_sessions:
                raise ValueError("The relay host is full. Stop an existing relay or try later.")
            relay = Relay(target, self.udp_bind, self.ports)
            ident, token = secrets.token_urlsafe(18), secrets.token_urlsafe(32)
            self.sessions[ident] = (token, relay)
            return {"id": ident, "token": token, **relay.snapshot(self.public_host)}

    def get(self, ident, token):
        with self.lock:
            session = self.sessions.get(ident)
        if session is None or not hmac.compare_digest(session[0], token):
            return None
        return session[1]

    def stop(self, ident, token):
        relay = self.get(ident, token)
        if relay is None:
            return False
        relay.close()
        with self.lock:
            self.sessions.pop(ident, None)
        return True

    def close(self):
        with self.lock:
            sessions = list(self.sessions.values())
            self.sessions.clear()
        for _, relay in sessions:
            relay.close()


def handler_for(controller):
    class Handler(BaseHTTPRequestHandler):
        server_version = "LunarVoid/1"

        def log_message(self, *_):
            pass  # No session IDs or credentials in access logs.

        def reply(self, status, data):
            body = json.dumps(data).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            self.wfile.write(body)

        def same_origin(self):
            origin = self.headers.get("Origin")
            return not origin or urlsplit(origin).netloc == self.headers.get("Host")

        def session(self):
            path = urlsplit(self.path).path
            if not re.fullmatch(r"/api/relay/[A-Za-z0-9_-]+", path):
                return None, ""
            auth = self.headers.get("Authorization", "")
            return path.rsplit("/", 1)[1], auth.removeprefix("Bearer ") if auth.startswith("Bearer ") else ""

        def do_GET(self):
            path = urlsplit(self.path).path
            if path == "/api/config":
                self.reply(200, {"requiresKey": bool(controller.access_key),
                                 "localOnly": controller.public_host == "127.0.0.1"})
            elif path.startswith("/api/relay/"):
                ident, token = self.session()
                relay = controller.get(ident, token)
                if relay is None:
                    self.reply(404, {"error": "Relay expired or unavailable. Start a new relay."})
                else:
                    self.reply(200, relay.snapshot(controller.public_host))
            elif path in ("/", "/index.html", "/dashboard/", "/dashboard/index.html",
                          "/downloads/LUNARVOID-PC-Windows-x64.zip", "/downloads/LUNARVOID-Android.apk"):
                site = ROOT / "site/build"
                if path in ("/", "/index.html"):
                    resource = site / "index.html"
                    if not resource.is_file():
                        resource = ROOT / "V15/dist/index.html"
                elif path.startswith("/dashboard/"):
                    resource = ROOT / "V15/dist/index.html"
                else:
                    resource = site / path.lstrip("/")
                    if not resource.is_file():
                        resource = ROOT / path.lstrip("/")
                if not resource.is_file():
                    self.reply(404, {"error": "Download not built yet."})
                    return
                content_type = {".zip": "application/zip", ".apk": "application/vnd.android.package-archive"}.get(
                    resource.suffix, "text/html; charset=utf-8")
                self.send_response(200)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(resource.stat().st_size))
                if path.startswith("/downloads/"):
                    self.send_header("Content-Disposition", 'attachment; filename="' + resource.name + '"')
                self.send_header("Cache-Control", "no-cache")
                self.send_header("X-Content-Type-Options", "nosniff")
                self.end_headers()
                with resource.open("rb") as stream:
                    while chunk := stream.read(65536):
                        self.wfile.write(chunk)
            else:
                self.reply(404, {"error": "Not found"})

        def do_POST(self):
            if self.path != "/api/relay":
                self.reply(404, {"error": "Not found"})
                return
            if not self.same_origin():
                self.reply(403, {"error": "Open the app on this relay host to start a connection."})
                return
            if controller.access_key and not hmac.compare_digest(
                    self.headers.get("X-Relay-Key", ""), controller.access_key):
                self.reply(401, {"error": "Enter the relay access key supplied by your host."})
                return
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if not 0 < length <= 2048 or self.headers.get_content_type() != "application/json":
                    raise ValueError("Send a small JSON server configuration.")
                self.connection.settimeout(10)
                data = json.loads(self.rfile.read(length))
                if not isinstance(data, dict):
                    raise ValueError("Invalid server configuration.")
                result = controller.start(data.get("host"), data.get("port"))
                self.reply(201, result)
            except (ValueError, OSError) as exc:
                self.reply(400, {"error": str(exc) if isinstance(exc, ValueError) else "The relay could not start. Check the server address and host configuration."})

        def do_DELETE(self):
            if not self.same_origin():
                self.reply(403, {"error": "Request origin does not match this relay host."})
                return
            ident, token = self.session()
            if ident and controller.stop(ident, token):
                self.reply(200, {"state": "stopped"})
            else:
                self.reply(404, {"error": "Relay already stopped or expired."})
    return Handler


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=3000)
    parser.add_argument("--public-host", default="127.0.0.1")
    parser.add_argument("--udp-bind", default="127.0.0.1")
    parser.add_argument("--udp-ports", default="19140-19155")
    parser.add_argument("--allow-lan", action="store_true")
    args = parser.parse_args()
    access_key = os.environ.get("LUNARVOID_ACCESS_KEY", "")
    if (args.host != "127.0.0.1" or args.public_host != "127.0.0.1" or args.udp_bind != "127.0.0.1") and len(access_key) < 24:
        parser.error("Public/LAN hosting requires LUNARVOID_ACCESS_KEY with at least 24 characters.")
    if not re.fullmatch(r"[A-Za-z0-9.-]{1,253}", args.public_host):
        parser.error("--public-host must be an IPv4 address or hostname, without a scheme or port.")
    try:
        ports = tuple(map(int, args.udp_ports.split("-")))
        if len(ports) != 2 or not 1 <= ports[0] <= ports[1] <= 65535:
            raise ValueError()
    except ValueError:
        parser.error("--udp-ports must be a range such as 19140-19155.")
    controller = Controller(args.public_host, args.udp_bind, ports, access_key, args.allow_lan)
    server = ThreadingHTTPServer((args.host, args.port), handler_for(controller))
    print(f"LUNARVOID web controller listening on http://{args.host}:{args.port}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        controller.close()


if __name__ == "__main__":
    main()
